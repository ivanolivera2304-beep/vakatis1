/**
 * Navbar — Vakatis Guest Relation
 * Design: Sol & Mar Editorial — azul marino profundo, logo Vakatis, dorado accent
 * Comportamiento: transparente sobre hero, sólido azul marino al hacer scroll
 */
import { useState, useEffect } from "react";
import { Menu, X, Phone } from "lucide-react";

const WHATSAPP_URL = "https://w.app/p2fix0";

const navLinks = [
  { label: "Actividades", href: "#actividades" },
  { label: "Experiencias", href: "#experiencias" },
  { label: "Galería", href: "#galeria" },
  { label: "Reservas", href: "#reservas" },
  { label: "Contacto", href: "#contacto" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[oklch(0.18_0.05_240/0.97)] backdrop-blur-xl shadow-lg shadow-[oklch(0.18_0.05_240/0.3)]"
          : "bg-transparent"
      }`}
    >
      <div className="container">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <a href="#" className="flex items-center gap-3 group">
            <img
              src="/manus-storage/vakatis-logo_79e1e5f7.png"
              alt="Vakatis Guest Relation"
              className="h-10 md:h-12 w-auto object-contain transition-transform duration-200 group-hover:scale-105"
            />
          </a>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-white/90 hover:text-[oklch(0.72_0.12_75)] font-body text-sm font-medium tracking-wide transition-colors duration-200 relative group"
              >
                {link.label}
                <span className="absolute -bottom-0.5 left-0 w-0 h-0.5 bg-[oklch(0.72_0.12_75)] transition-all duration-200 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* CTA */}
          <div className="hidden md:flex items-center gap-3">
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-5 py-2.5 rounded-full btn-gold font-body text-sm font-semibold"
            >
              <Phone size={15} />
              Reservar ahora
            </a>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="md:hidden text-white p-2 rounded-lg hover:bg-white/10 transition-colors"
            aria-label="Menú"
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`md:hidden transition-all duration-300 overflow-hidden ${
          menuOpen ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
        } bg-[oklch(0.18_0.05_240/0.98)] backdrop-blur-xl`}
      >
        <div className="container py-4 flex flex-col gap-4">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setMenuOpen(false)}
              className="text-white/90 hover:text-[oklch(0.72_0.12_75)] font-body text-base font-medium py-2 border-b border-white/10 transition-colors"
            >
              {link.label}
            </a>
          ))}
          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 px-5 py-3 rounded-full btn-gold font-body text-sm font-semibold mt-2"
          >
            <Phone size={15} />
            Reservar ahora
          </a>
        </div>
      </div>
    </header>
  );
}
