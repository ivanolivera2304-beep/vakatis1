/**
 * WhatsAppFloat — Vakatis Guest Relation
 * Botón flotante de WhatsApp con logo de Vakatis
 * Posicionado en la esquina inferior derecha, siempre visible
 */
import { useState } from "react";
import { X, MessageCircle } from "lucide-react";

const WHATSAPP_URL = "https://w.app/p2fix0";

export default function WhatsAppFloat() {
  const [showTooltip, setShowTooltip] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3">
      {/* Tooltip / Mini card */}
      {showTooltip && !dismissed && (
        <div className="relative bg-white rounded-2xl shadow-2xl p-4 max-w-xs border border-[oklch(0.88_0.02_220)] animate-fade-in-up">
          <button
            onClick={() => setDismissed(true)}
            className="absolute top-2 right-2 w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-200 transition-colors"
            aria-label="Cerrar"
          >
            <X size={12} />
          </button>
          <div className="flex items-center gap-3 mb-3">
            <img
              src="/manus-storage/vakatis-logo_79e1e5f7.png"
              alt="Vakatis"
              className="w-10 h-10 rounded-full object-cover"
            />
            <div>
              <p className="font-display text-sm font-bold text-[oklch(0.18_0.05_240)]">Vakatis Guest Relation</p>
              <p className="font-body text-xs text-green-500 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500 inline-block" />
                En línea ahora
              </p>
            </div>
          </div>
          <p className="font-body text-sm text-[oklch(0.35_0.05_240)] mb-3 leading-relaxed">
            ¡Hola! 👋 ¿Listo para vivir Costa del Sol como nunca? Escríbenos y te ayudamos a planificar tu experiencia perfecta.
          </p>
          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl bg-[#25D366] text-white font-body text-sm font-semibold hover:bg-[#1da851] transition-colors"
          >
            <MessageCircle size={15} />
            Iniciar conversación
          </a>
        </div>
      )}

      {/* Main WhatsApp Button with Vakatis Logo */}
      <a
        href={WHATSAPP_URL}
        target="_blank"
        rel="noopener noreferrer"
        className="whatsapp-float group"
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
        aria-label="Contactar por WhatsApp"
        title="Contactar por WhatsApp — Vakatis Guest Relation"
      >
        {/* Vakatis logo as button background */}
        <img
          src="/manus-storage/vakatis-logo_79e1e5f7.png"
          alt="Vakatis WhatsApp"
          className="w-full h-full object-cover rounded-full"
        />
        {/* WhatsApp icon overlay on hover */}
        <div className="absolute inset-0 rounded-full bg-[#25D366] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <svg viewBox="0 0 24 24" fill="white" className="w-7 h-7">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
          </svg>
        </div>
        {/* Pulse ring */}
        <span className="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-20" />
      </a>
    </div>
  );
}
