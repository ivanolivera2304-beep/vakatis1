export const ALERT_EMAIL = "ivanolivera2304@gmail.com";
export const FORMSUBMIT_URL = `https://formsubmit.co/${ALERT_EMAIL}`;
export const DEFAULT_WHATSAPP = "https://w.app/p2fix0";

export const bookingLinks: Record<string, string> = {
  "Bote VIP con Bebidas y Frutas": "https://fareharbor.com/embeds/book/fuengirola-sea-trips/items/527856/calendar/2026/07/?ref=vakatis-qrcode&sheet-uuid=38bfe724-fd6c-4aca-90b5-bee56289f3d8&asn=vakatis-eur&asn-ref=vakatis-qrcode&full-items=yes&flow=1133639",
  "Excursión de Delfines": "https://fareharbor.com/embeds/book/fuengirola-sea-trips/items/527836/calendar/2026/07/?ref=vakatis-qrcode&sheet-uuid=38bfe724-fd6c-4aca-90b5-bee56289f3d8&asn=vakatis-eur&asn-ref=vakatis-qrcode&full-items=yes&flow=1133638",
  "Parapente con Lancha": "https://fareharbor.com/embeds/book/fuengirola-sea-trips/items/601742/calendar/2026/07/?ref=vakatis-qrcode&sheet-uuid=38bfe724-fd6c-4aca-90b5-bee56289f3d8&asn=vakatis-eur&asn-ref=vakatis-qrcode&full-items=yes",
  "Caminito del Rey": "https://www.holidaytickets.es/reservar/whatson_h/",
  "Alquiler de Autos de Lujo": "https://w.app/2vbpre",
  "Flota de Autos de Lujo": "https://w.app/2vbpre",
  "Masajes a Domicilio": "https://w.app/wf15fg",
  "Restaurante Trocadero": "https://w.app/ycu0ng",
  "Gastronomía de Autor": "https://w.app/ycu0ng",
  "Acuario Costa del Sol": "https://www.holidaytickets.es/reservar/whatson/",
  "Acuario en Costa del Sol": "https://www.holidaytickets.es/reservar/whatson/",
  "Buggies y Cuatriciclos": "https://w.app/lbsirz",
  "Alquiler de Buggies y Cuatriciclos": "https://w.app/lbsirz",
  "Transfer Costa del Sol": "https://w.app/p2fix0",
  "Transfer en Costa del Sol": "https://w.app/p2fix0",
  "Transfer Premium": "https://w.app/p2fix0",
};

export function getBookingLink(title: string) {
  return bookingLinks[title] || DEFAULT_WHATSAPP;
}
