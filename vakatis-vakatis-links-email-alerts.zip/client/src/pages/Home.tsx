/**
 * Home — Vakatis Guest Relation
 * Design: Sol & Mar Editorial
 * Página principal con todas las secciones de la tienda de actividades turísticas
 * ORDEN: Navbar → Hero → Actividades → Experiencias → Servicios → Galería → RESERVAS → Por qué elegirnos → Footer
 */
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Activities from "@/components/Activities";
import FeaturedCarousel from "@/components/FeaturedCarousel";
import LuxuryServices from "@/components/LuxuryServices";
import Gallery from "@/components/Gallery";
import Booking from "@/components/Booking";
import WhyUs from "@/components/WhyUs";
import Footer from "@/components/Footer";
import WhatsAppFloat from "@/components/WhatsAppFloat";

export default function Home() {
  return (
    <div className="min-h-screen bg-[oklch(0.99_0.002_240)]">
      <Navbar />
      <Hero />
      <Activities />
      <FeaturedCarousel />
      <LuxuryServices />
      <Gallery />
      {/* Formulario de reservas justo arriba del título "Por qué elegirnos" */}
      <Booking />
      <WhyUs />
      <Footer />
      <WhatsAppFloat />
    </div>
  );
}
