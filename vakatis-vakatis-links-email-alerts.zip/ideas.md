# Vakatis Guest Relation — Ideas de Diseño

## Tres Enfoques Estilísticos

### Enfoque A: "Riviera Azul"
Estética mediterránea de lujo con gradientes oceánicos profundos, tipografía serif elegante y fotografías de gran formato. Probabilidad: 0.07

### Enfoque B: "Coastal Premium"
Minimalismo sofisticado con fondo blanco puro, acentos dorados y azul marino, fotografías a sangre, tipografía sans-serif moderna de alto contraste. Probabilidad: 0.04

### Enfoque C: "Sol & Mar Editorial"
Diseño editorial asimétrico inspirado en revistas de viaje de lujo: columnas desiguales, tipografía mixta serif/sans, fotografías superpuestas con overlays translúcidos, paleta azul-blanco-dorado. Probabilidad: 0.09

---

## Enfoque Elegido: **"Sol & Mar Editorial"** (C)

### Design Movement
Diseño editorial de revista de viajes de lujo — inspirado en publicaciones como Condé Nast Traveler y Monocle Travel.

### Core Principles
1. **Asimetría intencional**: columnas de ancho variable, imágenes que rompen la cuadrícula
2. **Jerarquía tipográfica fuerte**: contraste entre serif display y sans-serif funcional
3. **Fotografía como protagonista**: imágenes a sangre, overlays mínimos, mucho espacio para respirar
4. **Gradientes sutiles azul-blanco**: evocando el Mediterráneo sin caer en lo genérico

### Color Philosophy
- **Azul profundo**: `#0A2342` — autoridad, confianza, mar nocturno
- **Azul mediterráneo**: `#1B6CA8` — vitalidad, agua, cielo
- **Blanco arena**: `#F8F9FA` — limpieza, espacio, luz
- **Dorado acento**: `#C9A84C` — lujo, sol, exclusividad
- **Azul claro**: `#E8F4FD` — frescura, cielo, ligereza

### Layout Paradigm
Diseño de columnas editoriales asimétricas: secciones que alternan entre composiciones de 60/40, 70/30 y cuadrículas de 3 columnas. El hero ocupa pantalla completa con texto posicionado en el tercio inferior izquierdo.

### Signature Elements
1. Línea dorada delgada como separador de secciones y acento decorativo
2. Números grandes en azul claro como fondo decorativo en secciones de estadísticas
3. Tarjetas de actividad con imagen a sangre y overlay de gradiente en hover

### Interaction Philosophy
Transiciones suaves que evocan el movimiento del agua. Hover en tarjetas revela información adicional con deslizamiento desde abajo. El carrusel avanza con inercia natural.

### Animation
- Entrada de secciones: fade + translateY(20px) → translateY(0), 400ms ease-out
- Hover en tarjetas: scale(1.02) + sombra más profunda, 200ms
- Botones: scale(0.97) en active, 160ms
- Carrusel: transición con easing cúbico, 350ms

### Typography System
- **Display**: Playfair Display — serif elegante para títulos principales
- **Body**: DM Sans — sans-serif moderna y legible para cuerpo de texto
- **Accent**: DM Mono — para precios y datos numéricos
- Jerarquía: H1 4xl-6xl, H2 3xl, H3 xl, body base, caption sm

### Brand Essence
**Vakatis Guest Relation**: La puerta de entrada a las experiencias más exclusivas de Costa del Sol — para viajeros que exigen lo mejor.
Personalidad: **Sofisticado · Mediterráneo · Confiable**

### Brand Voice
Titular: "Vive Costa del Sol como nunca antes"
CTA: "Reserva tu experiencia"
Prohibido: "Bienvenido a nuestra web" / "Empieza hoy"

### Wordmark & Logo
Logo proporcionado por el cliente: VAKATIS con ola estilizada y estrella dorada sobre fondo azul marino. Usar en header con fondo transparente que se vuelve azul marino al hacer scroll.

### Signature Brand Color
**Azul Mediterráneo Profundo** `#0A2342` — inconfundiblemente Vakatis.
